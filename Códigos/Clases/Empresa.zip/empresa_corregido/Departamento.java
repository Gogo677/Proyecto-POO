import java.util.ArrayList;
import java.util.List;

public class Departamento {
	private String nombreDepartamento;
	private List<Empleado> empleados;
	
	public Departamento(){
		this.empleados=new ArrayList<Empleado>();
	}
	
	public void setNombreDepartamento(String nombreDepartamento){
		this.nombreDepartamento = nombreDepartamento;
	}
	
	public String getNombreDepartamento(){
		return this.nombreDepartamento;
	}
	
	public void setEmpleados(List<Empleado> empleados){
		this.empleados = empleados;
	}
	
	public List<Empleado> getEmpleados(){
		return this.empleados;
	}
	

}
