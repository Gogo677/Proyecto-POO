import java.util.ArrayList;
import java.util.List;

public class Empresa {
	private String nomEm;
	private List<Departamento> deptos;
	private List<Puesto> puestos;
	
	public Empresa(){
		this.puestos=new ArrayList<Puesto>();
		this.deptos=new ArrayList<Departamento>();
	}
	
	public void altaActSalario(String puesto, float salario){	
		Integer pos=existePuesto(puesto);
		
		if(pos!=null){
			//actualizacion
			puestos.get(pos).setSalario(salario);			
		}else{
			//alta
		Puesto pAux=new Puesto(puesto.trim().toUpperCase(), salario);			
		puestos.add(pAux);
		}		
	}
	public String listaEmpleados()
	{
		String cadena="";
		for(int i=0; i<deptos.size(); i++)
		{
			for(int j=0; j<deptos.size();j++)
			{
				cadena+=deptos.get(i).getEmpleados().get(j).getNomEmp();
			}
		}
		return cadena;
	}
	
	public String listaEmpleadosDepto(String nombreDepto)
	{
		Integer i;
		String cadena="";
		
		i=existeDepto(nombreDepto);
		if(i!=null)
		{
			for(int j=0; j<deptos.size();j++)
			{
				cadena+=deptos.get(i).getEmpleados().get(j).getNomEmp() + "\n";
			}	
		}
		else
		{
			cadena= " No se encontr� departamento";
		}
		return cadena;
	}
	
	public void eliminarEmpleado(int posdepto,int numEmp)
	{
		for(int i=0; i<deptos.get(posdepto).getEmpleados().size();i++)
		{
			if(this.deptos.get(posdepto).getEmpleados().get(i).getNumEmp()==numEmp)
			{
				this.deptos.get(posdepto).getEmpleados().remove(i);
			}
		}
	}
	
	public Empleado buscarEmpleado(int numEmp){	
		Empleado e=null;
		
		for(int contador=0; contador<deptos.size(); contador++){ //departamento	
		  for(int contador2=0; 
			contador2<deptos.get(contador).getEmpleados().size();
				contador2++){//departamento
			  
			  if(deptos.get(contador).getEmpleados().get(contador2).getNumEmp()
				==numEmp){
				  e=deptos.get(contador).getEmpleados().get(contador2);
				  //posicionDepartamento contador
				  e.setPosDepto(contador);
				  //posicionEmpleado contador2
				  e.setPosEmp(contador2);
				  
				  break;
			  }
		  }//for 2
		  
		  if(e!=null)
			  break;
		}//for 1
		
		return e;
	}
	
	public Integer existePuesto(String puesto){
		Integer resp=null;
		
		for(int i=0; i<puestos.size(); i++){
			if(puestos.get(i).getNombrePuesto().
					equals(puesto.trim().toUpperCase())){				
				resp=i;
				break;
			}			
		}		
		
		return resp;		
	}
	
	public String imprimir(){
		String cadena="";
		cadena= " Lista de Puestos";
		for(Puesto p : puestos){
			cadena+="\nPuesto: "+p.getNombrePuesto()
					+" Salario: "+p.getSalario();
		}
		
		return cadena;
	}
	
	public String imprimirDeptos(){
		String cadena="";
		
		for(Departamento d : deptos){
			cadena+="\nDepto: "+d.getNombreDepartamento().toUpperCase()
					+" Total Empleados: "+d.getEmpleados().size();
		}
		
		return cadena;
	}
	public String imprimirTotEmp()
	{
		String cad="";
		int cont=0;
		for(Departamento d: deptos)
		{
		cont+=d.getEmpleados().size();	
		}
		cad="\nTotal Empleados de la Empresa: " + cont;
		return cad;
	}
	
	
	public String getNombresPuestos(){
		String puestosCade="";
		
		for(int i=0; i<puestos.size(); i++){
			puestosCade+=puestos.get(i).getNombrePuesto()+", ";
		}
		
		if(puestosCade.length()>0){
			puestosCade=puestosCade.substring(0, 
					puestosCade.length()-2);
		}
			
		return puestosCade;
	}
	
	public Departamento getDepto(String nomDepto){
		Departamento depto;
		Integer posicion=null;
		
		posicion=existePuesto(nomDepto);
		
		depto=deptos.get(posicion);
		
		return depto;
	}
	public String getNombresDeptos(){
		String deptosCade="";
		
		for(int i=0; i<deptos.size(); i++){
			deptosCade+=deptos.get(i).getNombreDepartamento()+", ";
		}
		
		if(deptosCade.length()>0){
			deptosCade=deptosCade.substring(0, 
					deptosCade.length()-2);
		}
			
		return deptosCade;
	}
	
	public Puesto getPuesto(String nomPuesto){
		Puesto puesto;
		Integer posicion=null;
		
		posicion=existePuesto(nomPuesto);
		
		puesto=puestos.get(posicion);
		
		return puesto;
	}
	
	public void altaEmpleado(Empleado emp, String depto){		
		Integer posDepto=null;
		
		posDepto=existeDepto(depto);
		
		if(posDepto!=null){
			//existe Departamento
			deptos.get(posDepto).getEmpleados().add(emp);
			
		}else{
			//no existe depto
			Departamento d=new Departamento();
			
			d.setNombreDepartamento(depto.trim().toUpperCase());
			d.getEmpleados().add(emp);
			
			deptos.add(d);
		}
	}
	
	public Integer existeDepto(String departamento){
		Integer resp=null;
		
		for(int i=0; i<deptos.size(); i++){
			if(deptos.get(i).getNombreDepartamento().
					equals(departamento.trim().toUpperCase())){				
				resp=i;
				break;
			}			
		}		
		
		return resp;		
	}
	
	public String getNomEm(){
		return this.nomEm;
	}
	public void setNomEm(String nomEm){
		this.nomEm=nomEm;
	}
	
	public List<Departamento> getDeptos(){
		return this.deptos;
	}
	public void setDeptos(List<Departamento> deptos){
		this.deptos=deptos;
	}
	
	public List<Puesto> getPuestos(){
		return this.puestos;
	}
	public void setPuestos(List<Puesto> puestos){
		this.puestos=puestos;
	}

}