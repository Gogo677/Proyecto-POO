

public class Empleado {
	private String nomEmp;
	private int numEmp;
	private Puesto puestito;
	private int posDepto;
	private int posEmp;

	public String getNomEmp (){
		return this.nomEmp;
	}
	
	public void setNomEmp (String nomEmp){
		this.nomEmp=nomEmp;
	}
	
	public int getNumEmp (){
		return this.numEmp;
	}
	
	public void setPosDepto (int posDepto){
		this.posDepto=posDepto;
	}
	
	public int getPosDepto (){
		return this.posDepto;
	}
	
	public void setPuestito (Puesto puestito){
		this.puestito=puestito;
	}
	public Puesto getPuestito (){
		return this.puestito;
	}
	public int getposEmp(){
		return this.posEmp;
	}
	
	public void setPosEmp (int posEmp){
		this.posEmp=posEmp;
	}
	public void setNumEmp (int numEmp){
		this.numEmp=numEmp;
	}
}

 