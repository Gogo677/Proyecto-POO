public class Puesto {
	private String nombrePuesto;
	private float salario;
	
	public Puesto(String nombrePuesto, float salario){
		this.nombrePuesto=nombrePuesto;
		this.salario=salario;
	}
	
	public void setNombrePuesto(String nombrePuesto){
		this.nombrePuesto = nombrePuesto;
	}
	
	public String getNombrePuesto(){
		return this.nombrePuesto;
	}
	
	public void setSalario(float salario){
		this.salario = salario;
	}
	
	public float getSalario(){
		return this.salario;
	}
}
