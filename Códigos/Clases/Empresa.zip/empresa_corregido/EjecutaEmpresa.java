import javax.swing.JOptionPane;

public class EjecutaEmpresa {

	public static void main(String[] args) {
		Empresa e=new Empresa();
		int opcion=0;
		
		e.setNomEm(JOptionPane.
			showInputDialog("Ingresa el nombre de la empresa"));
		
		do{
			opcion=Integer.parseInt(JOptionPane.showInputDialog(
					"1 Alta Empleado"+
					"\n2 Actualiza Empleado"+//busqueda por numero de empleado 
					"\n3 Salario"+
					"\n4 Total de Empleados"+ 
					"\n5 Total de Empleados por Departamento"+
					"\n6 Informaci�n Empleado"+ 
					"\n7 Imprimir"+
					"\n8 Salir"));
			
			switch (opcion) {
			case 1:
				Empleado emp=new Empleado();
				String departamento="";
				Puesto puestito;
				Departamento deptito;
				
				
				emp.setNomEmp(JOptionPane.showInputDialog(
						"Ingrese el Nombre del Empleado"));
				
				emp.setNumEmp(
						Integer.parseInt(JOptionPane.showInputDialog(
						"Ingrese el N�mero del Empleado")));
				
				puestito=e.getPuesto(JOptionPane.showInputDialog(
						"Ingrese el Puesto ("+e.getNombresPuestos()+")"));
				
				emp.setPuestito(puestito);
				
				departamento=JOptionPane.showInputDialog(
						"Ingrese el Departamento del Empleado");
				//TODO: validar alta de empleado repetido y enviar mensaje
				e.altaEmpleado(emp, departamento);
				
				break;
			case 2:
				Empleado empleado=null;
				Integer num=null;
				String puestoCad="";
				
				num=Integer.parseInt(JOptionPane.showInputDialog("Ingres N�mero de "
						+ "Empleado a Actualizar"));
				
				empleado=e.buscarEmpleado(num);
				
				if(empleado==null){
					JOptionPane.showMessageDialog(null, "El empleado No Existe");
				}else{				
					empleado.setNomEmp(JOptionPane.showInputDialog(
							"Actualiza el Nombre del Empleado",
							empleado.getNomEmp()));
					
					empleado.setNumEmp(
							Integer.parseInt(JOptionPane.showInputDialog(
							"Actualiza el N�mero del Empleado",
							empleado.getNumEmp())));
					
					puestoCad=JOptionPane.showInputDialog(
							"Actualiza el Puesto ("+e.getNombresPuestos()+")",
							empleado.getPuestito().getNombrePuesto());
					
					if(!puestoCad.trim().toUpperCase().
							equals(empleado.getPuestito().getNombrePuesto())){
						puestito=e.getPuesto(puestoCad);						
						empleado.setPuestito(puestito);	
					}
					
					departamento=JOptionPane.showInputDialog(
							"Actualice el Departamento del Empleado ("+e.getNombresDeptos()+")",
							e.getDeptos().get(empleado.getPosDepto()).getNombreDepartamento());
					
					e.eliminarEmpleado(empleado.getPosDepto(), empleado.getNumEmp());
					e.altaEmpleado(empleado, departamento);
					
				}
				break;
			case 3:
				//alta o actuaizacion salarios
				String puesto="";
				float salario=0f;
				
				puesto=JOptionPane.showInputDialog(
						"Ingrese el puesto");
				salario=Float.parseFloat(JOptionPane.showInputDialog(
						"Ingrese el salario"));
				
				e.altaActSalario(puesto,salario);
				
				break;
			case 4:
				JOptionPane.showMessageDialog(null, e.imprimirTotEmp());
				break;
			case 5:
				JOptionPane.showMessageDialog(null, e.imprimirDeptos());
					break;
			case 6:
				Empleado empl=null;
				Integer numb=null;
				numb=Integer.parseInt(JOptionPane.showInputDialog("Ingrese N�mero de "
						+ "Empleado a Buscar"));
				
				empl=e.buscarEmpleado(numb);
				
				if(empl==null){
					JOptionPane.showMessageDialog(null, "El empleado No Existe");
				}
				else
				{
				JOptionPane.showMessageDialog(null, "\nNombre: " + empl.getNomEmp().toUpperCase()
						+ "\nN�mero Empleado: " + empl.getNumEmp()
						+ "\nPuesto: " + empl.getPuestito().getNombrePuesto().toUpperCase()
						+ "\nSalario: " + empl.getPuestito().getSalario());
				}
				break;
			case 7:
				JOptionPane.showMessageDialog(null, e.imprimir());
				JOptionPane.showMessageDialog(null, e.imprimirDeptos());
				break;
			case 8:
				
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opci�n Invalida");
				break;
			}
			
		}while(opcion!=8);
		
		JOptionPane.showMessageDialog(null, "Salir");
	}

}
