public class Especialidad {
    private String esp;
    private String hospital;
     
    public String getEsp(){
        return this.esp;
    }
     
    public void setEsp(String esp){
        this.esp=esp;
    }
     
    public String getHosp(){
        return this.hospital;
    }
     
    public void setHosp(String hospital)
    {
        this.hospital=hospital;
    }
     
}