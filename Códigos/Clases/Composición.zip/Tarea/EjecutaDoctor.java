import javax.swing.JOptionPane;
 
public class EjecutaDoctor {
     
    public static void main(String args[]){
        Doctor per = new Doctor();
         
        per.setNombre(JOptionPane.showInputDialog("Nombre del doctor: "));
        per.setCedula(Integer.parseInt(JOptionPane.showInputDialog("C�dula del doctor: ")));
     
        //accede a los metodos de la clase Especialidad y llena datos del objeto
        per.getEspec().setEsp(JOptionPane.showInputDialog("Especialidad: "));
        per.getEspec().setHosp(JOptionPane.showInputDialog("Hospital: "));
         
         
        //impresion
        JOptionPane.showMessageDialog(null,per.imprimir());
    }
     
}
