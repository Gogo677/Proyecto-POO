public class Doctor {
     
    public Doctor(){
        this.espec = new Especialidad();
    }
     
    private String nombre;
    private int cedula;
    private Especialidad espec;
     
    public Especialidad getEspec(){
        return this.espec;
    }
     
    public void setEspec(Especialidad espec){
        this.espec=espec;
    }
     
    public String getNombre(){
        return this.nombre;
    }
     
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
     
    public int getCedula(){
        return this.cedula;
    }
     
    public void setCedula(int cedula){
        this.cedula=cedula;
    }
     
    public String imprimir(){
        return("Nombre: " + nombre.toUpperCase() + "\nC�dula: " +
                cedula + "\nEspecialidad: " + espec.getEsp().toUpperCase() 
                + "\nHospital: " +espec.getHosp().toUpperCase()); 
                //obtiene la especialidad con el atributo espec o con el metodo
    }
     
}
