package treinta_sep;

import javax.swing.JOptionPane;

public class EjecutaSuperama {
	public static void main(String args[])
	{
		Producto prod= new Producto();
		ProductoCongelado frio= new ProductoCongelado();
		ProductoFresco lechuga= new ProductoFresco();
		ProductoRefrigerado  mabe = new ProductoRefrigerado();
		prod.setNomProd("Lala Capit�n America");
		JOptionPane.showMessageDialog(null,frio.imprimir());
		JOptionPane.showMessageDialog(null,lechuga.imprimir());
		JOptionPane.showMessageDialog(null,mabe.imprimir());
	}

}
