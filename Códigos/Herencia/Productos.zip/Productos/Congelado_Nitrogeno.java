package treinta_sep;

public class Congelado_Nitrogeno extends ProductoCongelado {
	private int tiempoExpNitrogeno;
	public int getTiempoExpNitrogeno()
	{
	 return tiempoExpNitrogeno;
	}
	public void setTiempoExpNitrogeno(int tiempoExpNitrogeno)
	{
	 this.tiempoExpNitrogeno=tiempoExpNitrogeno;	
	}
	public String imprimir()
	{
	String cad=null;
	cad+="";
	return cad;
	}
}
