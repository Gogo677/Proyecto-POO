package treinta_sep;

import java.util.Date;


public class Producto {
	private String nomEmpresa;
	private int numLote;
	private int numPasillo;
    private int numRefrigerador;
	private Date fechaCad;
	public String getNomEmpresa() {
		return nomEmpresa;
	}
	public void setNomEmpresa(String nomEmpresa) {
		this.nomEmpresa = nomEmpresa;
	}
	public Date getFecha() {
		return fechaCad;
	}
	public void setFecha(Date fechaCad) {
		this.fechaCad = fechaCad;
	}
	public int getNumLote() {
		return numLote;
	}
	public void setNumLote(int numLote) {
		this.numLote = numLote;
	}
	public int getNumPasillo() {
		return numPasillo;
	}
	public void setNumPasillo(int numPasillo) {
		this.numPasillo = numPasillo;
	}
	public int getNumRefrigerador() {
		return numRefrigerador;
	}
	public void setNumRefrigerador(int numRefrigerador) {
		this.numRefrigerador = numRefrigerador;
	}
	
	public String imprimir()
	{
	 String cadena=null;
	 cadena+="Nombre Producto: " + nomEmpresa.toUpperCase() + "\nN�mero de Lote: " + numLote + 
			 "\nN�mero de Pasillo: " + numPasillo + "\nN�mero de Refrigerador: " + numRefrigerador
			 + "\nFecha de caducidad: " + fechaCad;
	 return cadena;
	}
  
}
