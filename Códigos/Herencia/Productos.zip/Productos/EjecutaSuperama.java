package treinta_sep;

public class EjecutaSuperama {
	public static void main(String args[])
	{
		Superama supera = new Superama();
	}

}
