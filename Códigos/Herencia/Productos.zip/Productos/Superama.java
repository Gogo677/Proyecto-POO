package treinta_sep;

public class Superama {

	String nombreSuper;
}
