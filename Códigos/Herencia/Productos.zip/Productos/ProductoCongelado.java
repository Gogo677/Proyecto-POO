package treinta_sep;
import java.util.Date;
public class ProductoCongelado {

	private String paisOrigen;
    public String getPaisOrigen() {
		return paisOrigen;
	}
	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}
	public double getTempMaxcon() {
		return tempMaxcon;
	}
	public void setTempMaxcon(double tempMaxcon) {
		this.tempMaxcon = tempMaxcon;
	}
	public double getTempMincon() {
		return tempMincon;
	}
	public void setTempMincon(double tempMincon) {
		this.tempMincon = tempMincon;
	}
	public Date getFechaFabricacion() {
		return fechaFabricacion;
	}
	public void setFechaFabricacion(Date fechaFabricacion) {
		this.fechaFabricacion = fechaFabricacion;
	}
	private double tempMaxcon;
    private double tempMincon;
    private Date fechaFabricacion;
    public String imprimir()
	{
	String cad=null;
	cad+="";
	return cad;
	}
}
