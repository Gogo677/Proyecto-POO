package treinta_sep;
public class ProductoRefrigerado extends Producto {

	private double temperaturaMantenimiento;
	public double getTemperaturaMantenimiento() {
		return temperaturaMantenimiento;
	}
	public void setTemperaturaMantenimiento(double temperaturaMantenimiento) {
		this.temperaturaMantenimiento = temperaturaMantenimiento;
	}
	public int getCodigoSupAli() {
		return codigoSupAli;
	}
	public void setCodigoSupAli(int codigoSupAli) {
		this.codigoSupAli = codigoSupAli;
	}
	private int codigoSupAli;
	
	public String imprimir()
	{
	String cad=null;
	cad+="";
	return cad;
	}
}
