package treinta_sep;

public class Congelado_Agua extends ProductoCongelado {
private int salidadAgua;
public int getsalidadAgua()
{
 return salidadAgua;
}
public void setsalidadAgua(int salidadAgua)
{
 this.salidadAgua=salidadAgua;	
}
public String imprimir()
{
String cad=null;
cad+="";
return cad;
}
}


